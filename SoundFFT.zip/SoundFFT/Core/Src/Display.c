//#include "DisplayFont.h"
#include "Display.h"
#include "lv_app_main.h"

uint16_t Display_Buf[14][2]={0};
uint16_t Display_ScanBuf[14][2]={0};
/*底层：******************************************************************/
void Display_Init(void)
{
  LCD_Init();
}	

void Display_ClearBuf(void)
{
	uint16_t i;
	for(i=0;i<14;i++)
	{
    Display_Buf[i][0]=0;
    Display_Buf[i][1]=0;
	}
}

void Display_Update(void)
{
  uint16_t i;
	for(i=0;i<14;i++)
	{
    if(Display_Buf[i][1]!=Display_ScanBuf[i][1])
    {
//      LCD_Fill(MIDDLE,i*23+3,LCD_M_H-Display_ScanBuf[i][1]-4,i*23+18,LCD_M_H-Display_ScanBuf[i][1],BLACK);
//      LCD_Fill(MIDDLE,i*23+3,LCD_M_H-Display_Buf[i][1]-4,i*23+18,LCD_M_H-Display_Buf[i][1],RED);
      
      ser_array[i] = Display_Buf[i][0];

//      LCD_Fill(MIDDLE,i*23+3,LCD_M_H-1-Display_Buf[i][0],i*23+18,LCD_M_H-Display_ScanBuf[i][0],GREEN);
    }
//    if(Display_Buf[i][0]>Display_ScanBuf[i][0])
//    {
//      LCD_Fill(MIDDLE,i*23+3,LCD_M_H-1-Display_Buf[i][0],i*23+18,LCD_M_H-Display_ScanBuf[i][0],GREEN);
//    }
//    else
//    if(Display_Buf[i][0]<Display_ScanBuf[i][0])
//    {
//      LCD_Fill(MIDDLE,i*23+3,LCD_M_H-1-Display_ScanBuf[i][0],i*23+18,LCD_M_H-Display_Buf[i][0]-1,BLACK);
//    }
    Display_ScanBuf[i][0]=Display_Buf[i][0];
    Display_ScanBuf[i][1]=Display_Buf[i][1];
	}
  lv_chart_refresh(ui_FFT); /*Required after direct set*/
}


void Display_Clear(void)
{
	Display_ClearBuf();
	Display_Update();
}
void Display_SetLevel(uint16_t X,uint16_t Level,uint16_t Color)
{
	Display_Buf[X/5][0]=Level;
}
void Display_ShowPoint(uint16_t X,uint16_t Y,uint16_t Color)
{
	Display_Buf[X/5][1]=Y;
}

//void Display_ClearBuf(void)
//{
//	uint16_t i,j;
//	for(i=0;i<LCD_M_H;i++)
//	{
//		for(j=0;j<LCD_M_W;j++)
//		{
//			Display_Buf[i][j][0]=0;
//			Display_Buf[i][j][1]=0;
//		}
//	}
//}

//void Display_ClearAreaBuf(uint16_t StartX,uint16_t EndX,uint16_t StartY,uint16_t EndY)
//{
//	uint16_t i,j;
//	for(i=StartY;i<EndY;i++)
//	{
//		for(j=StartX;j<EndX;j++)
//		{
//			Display_Buf[LCD_M_H-1-i][j][0]=0;
//			Display_Buf[LCD_M_H-1-i][j][1]=0;
//		}
//	}
//}

//void Display_Update(void)
//{
//  LCD_ShowPicture(MIDDLE,0,0,LCD_M_W,LCD_M_H,(uint8_t*)Display_Buf);
////	uint16_t i,j;
//  /***************等待填写********************/
////	for(i=0;i<64;i++)
////	{
////		for(j=0;j<32;j++)
////		{
////			Display_ScanBuf[i][j]=Display_Buf[i][j];
////		}
////	}
//}

//void Display_SetLevel(uint16_t X,uint16_t Level,uint16_t Color)
//{
//	uint8_t i;
//	for(i=0;i<=Level;i++)
//	{
//		Display_Buf[i][X][0]=Color>>8;
//		Display_Buf[i][X][1]=Color;
//	}
//}

//void Display_Clear(void)
//{
//	Display_ClearBuf();
//	Display_Update();
//}

//void Display_ShowPoint(uint16_t X,uint16_t Y,uint16_t Color)
//{
//  Display_Buf[LCD_M_H-1-Y][X][0]=Color>>8;
//  Display_Buf[LCD_M_H-1-Y][X][1]=Color;
//}

//void Display_ShowChar(uint16_t X,uint16_t Y,char Char,uint8_t SizeColor)
//{
//  LCD_ShowChar(MIDDLE,X,Y,Char,WHITE,BLACK,SizeColor,1);
//}

//void Display_ShowString(uint16_t X,uint16_t Y,char *String,uint8_t SizeColor)
//{
//  LCD_ShowString(MIDDLE,X,Y,(uint8_t*)String,WHITE,BLACK,SizeColor,1);
//}

//void Display_ShowNumber(uint16_t X,uint16_t Y,uint16_t Number,uint8_t Length,uint8_t SizeColor)
//{
//  LCD_ShowIntNum(MIDDLE,X,Y,Number,Length,WHITE,BLACK,SizeColor);
//}

//void Display_ShowPoint(uint16_t X,uint16_t Y,uint16_t Color)
//{
//	LCD_DrawPoint(MIDDLE,X,Y,Color);
//}
