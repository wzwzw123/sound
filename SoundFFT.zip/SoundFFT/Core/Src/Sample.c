#include "Sample.h"
#include "adc.h"
#include "tim.h"

volatile HAL_StatusTypeDef sample_status = HAL_BUSY;
uint16_t adc_buf[sample_num];
uint16_t *Sample_Value;

void Sample_Init(void)
{
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
	Sample_Value=adc_buf;
}

void Sample_GetValue(void)
{
	sample_status = HAL_BUSY;
	HAL_ADC_Start_DMA(&hadc1,(uint32_t *)adc_buf,sample_num);
	while(sample_status != HAL_OK);
}
