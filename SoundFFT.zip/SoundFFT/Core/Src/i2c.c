/*
 * i2c.c:
 * Copyright (c) 2014-2017 Rtrobot. <admin@rtrobot.org>
 *  <http://rtrobot.org>
 ***********************************************************************
 * use keil5 for arm.
 */
 
#include "i2c.h"
#include "delay.h"

#define SDA_HIGH   I2C_SDA_Set()
#define SDA_LOW    I2C_SDA_Clr()
#define SCL_HIGH   I2C_SCL_Set()
#define SCL_LOW    I2C_SCL_Clr()

#define SDA_INPUT  I2C_SDA

/***************************************************************************************************************
*switch SDA GPIO input or output
****************************************************************************************************************/
void SDA_SetGpioMode(bool mode)
{
    if(mode==1)
      I2C_SDA_OUT()
    else
      I2C_SDA_IN()
}

/***************************************************************************************************************
*Simulated I2C delay
****************************************************************************************************************/
static void IIC_delay(uint16_t n)
{
    HAL_Delayus(30);
}


/***************************************************************************************************************
*Simulated I2C start
****************************************************************************************************************/
void IIC_Start(void)
{
    SDA_HIGH;                    
    SCL_HIGH;
    IIC_delay(1);
    SDA_LOW;
    IIC_delay(1);
    SCL_LOW;
}

/***************************************************************************************************************
*Simulated I2C STOP
****************************************************************************************************************/
void IIC_Stop(void)
{
    SCL_LOW;
    SDA_LOW;
    IIC_delay(1);
    SCL_HIGH;
    SDA_HIGH;
    IIC_delay(1);
}

/***************************************************************************************************************
* send one byte
****************************************************************************************************************/
void IIC_SendByte(uint8_t data)
{
    uint8_t i=0;
    for (i=0; i<8; i++)
    {
        if(data&0x80)
            SDA_HIGH;
        else
            SDA_LOW;
        SCL_HIGH;
        IIC_delay(1);
        SCL_LOW;
        IIC_delay(1);
        data<<=1;
    }
}

/***************************************************************************************************************
* receive one byte
****************************************************************************************************************/
uint8_t IIC_RecvByte(void)
{
    uint8_t i;
    uint8_t temp = 0;
    SDA_SetGpioMode(0);//set sda gpio input
    for (i=0; i<8; i++)
    {
        SCL_LOW;
        temp <<= 1;
        SCL_HIGH;
        IIC_delay(1);//if ID is not 0xAB,try to modification value
        temp|= SDA_INPUT;
        SCL_LOW;
        IIC_delay(1);//if ID is not 0xAB,try to modification value
    }
    SDA_SetGpioMode(1);//set sda gpio output
    return temp;
}

/***************************************************************************************************************
* wait for a response
****************************************************************************************************************/
int8_t IIC_RecvACK(void)
{
    uint8_t wait=0xff;
    SDA_SetGpioMode(0);//set sda gpio input
    SCL_HIGH;
    while (SDA_INPUT&&wait--);
    if(wait<=0)
    {
        IIC_Stop();
        return -1;
    }
    SDA_INPUT;
    SCL_LOW;
    IIC_delay(1);
    SDA_SetGpioMode(1);//set sda gpio output
    return 0;
}

/***************************************************************************************************************
*response ACK; ack==1,response; ack==0,none; 
****************************************************************************************************************/
void IIC_SendACK(uint8_t ack)
{
    SCL_LOW;
    if (ack)
        SDA_HIGH;
    else
        SDA_LOW;   
    IIC_delay(1);
    SCL_HIGH;
    IIC_delay(1);                 
    SCL_LOW;             
}

/***************************************************************************************************************
* I2C write data
****************************************************************************************************************/
void IIC_WriteReg(uint8_t i2c_addr, uint8_t reg_addr, uint8_t reg_data)
{
    IIC_Start();
    IIC_SendByte((i2c_addr<<1)|0);
    IIC_RecvACK(); 
    IIC_SendByte(reg_addr);
    IIC_RecvACK();
    IIC_SendByte(reg_data);
    IIC_RecvACK();
    IIC_Stop();
}

/***************************************************************************************************************
*receive one bytes to 'pdata'
****************************************************************************************************************/
void IIC_ReadData(uint8_t i2c_addr, uint8_t reg_addr, uint8_t *pdata)
{
    IIC_Start();
    IIC_SendByte((i2c_addr<<1)|0x00);
    IIC_RecvACK();
    IIC_SendByte(reg_addr);
    IIC_RecvACK();
    IIC_Start();
    IIC_SendByte((i2c_addr<<1)|0x01);
    IIC_RecvACK();
    *pdata=IIC_RecvByte();
    IIC_SendACK(1);
    IIC_Stop();
}
/***************************************************************************************************************
*Reads a block (array) of bytes from the I2C device and register
****************************************************************************************************************/
int32_t IIC_ReadDataBlock(uint8_t i2c_addr, uint8_t reg_data, uint8_t *pdata, uint32_t count)
{
    uint8_t i = 0;
    uint8_t y = 0;
    IIC_Start(); 
    IIC_SendByte((i2c_addr<<1)|0x00);	
    if(IIC_RecvACK()==-1)
    {
        IIC_Stop();		 
        return -1;
    }
    IIC_SendByte(reg_data);
    IIC_RecvACK();
    IIC_Start();
	IIC_SendByte((i2c_addr<<1)|0x01);
    IIC_RecvACK();
    for(i = 0; i <count; i++)
    {
        *pdata=IIC_RecvByte();
        if(count==(i+1))
            IIC_SendACK(1);
        else
            IIC_SendACK(0);
        pdata++;
        y++;
    }
    IIC_Stop();
    return y;
}
