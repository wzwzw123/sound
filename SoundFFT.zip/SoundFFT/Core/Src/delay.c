#include "delay.h"
#include "main.h"
#include "dwt.h"

void HAL_DelayInit(void)
{
	DWT_Init();
}

void HAL_Delayus(uint32_t us)
{
#if defined(DWT_BASE) && !defined(DWT_DELAY_DISABLED)
  int32_t start  = DWT_GetCycles();
  int32_t cycles = us * (SystemCoreClock / 1000000);

  while ((int32_t)DWT_GetCycles() - start < cycles);
#endif
}

void HAL_Delayms(uint32_t ms)
{
	HAL_Delay(ms);
}
