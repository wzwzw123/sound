#include "Sample.h"
#include "FFT.h"
#include "delay.h"
#include "Display.h"
const uint16_t Spectrum_Pointer[14] = {1,2,3,5,8,13,21,32,51,80,128,200,320,511};
uint8_t Spectrum_Level[14];
uint16_t Spectrum_Dot[14];

uint8_t Spectrum_SoundFlag;
uint8_t Spectrum_StopFlag=1;

uint16_t Spectrum_Count;
uint8_t Spectrum_ModeSwitchFlag=0;


void Spectrum_GetValue(void);

void Spectrum_Init(void)
{
//	Spectrum_Type=AT24C02_ReadByte(2);
//	if(Spectrum_Type>15){Spectrum_Type=0;}
//	Spectrum_ModeSwitchFlag=AT24C02_ReadByte(3);
//	if(Spectrum_ModeSwitchFlag>1){Spectrum_ModeSwitchFlag=0;}
	Sample_Init();
	FFT_Init();
//	Spectrum_GetValue();
	Spectrum_Count=100;
}

void Spectrum_GetValue(void)
{
	uint16_t i;
	uint32_t Sum=0;
	Sample_GetValue();
	for(i=0;i<sample_num;i++)
	{
		x[i].Real=Sample_Value[i]-2048;
		x[i].Imag=0;
	}
	FFT();
	for(i=0;i<14;i++)
	{
		Spectrum_Level[i]=sqrt(x[Spectrum_Pointer[i]].Real*x[Spectrum_Pointer[i]].Real+x[Spectrum_Pointer[i]].Imag*x[Spectrum_Pointer[i]].Imag)/64;
		if(i!=0){Sum+=Spectrum_Level[i];}
	}
//	Spectrum_Level[0]=(Spectrum_Level[1]+Spectrum_Level[2])/2;
  
	Display_ClearBuf();
	if(Sum>400)
	{
		Spectrum_SoundFlag=1;
	}
	else
	{
		Spectrum_SoundFlag=0;
	}
}

void Spectrum_Show(void)
{
	uint16_t i;
	if(Spectrum_SoundFlag==0)
	{
		Spectrum_Count++;
		if(Spectrum_Count>200)
		{
			Spectrum_StopFlag=1;
		}
		if(Spectrum_Count>1000)
		{
			Spectrum_Count=1000;
		}
	}
	else
	{
		Spectrum_Count=0;
		Spectrum_StopFlag=0;
	}
  
  for(i=0;i<14;i++)
  {
    if(Spectrum_StopFlag)Spectrum_Level[i]=0;
    if(Spectrum_Level[i]>LCD_M_H-5)Spectrum_Level[i]=LCD_M_H-5;
    if(Spectrum_Dot[i]/10<Spectrum_Level[i]+5)
    {
      Spectrum_Dot[i]=(Spectrum_Level[i]+1)*10;
    }
    else if(Spectrum_Dot[i]/10>=5)
    {
      Spectrum_Dot[i]-=50;
    }
    //LCD��ʾ
    Display_SetLevel(i*5+1,Spectrum_Level[i],GREEN);
    Display_SetLevel(i*5+2,Spectrum_Level[i],GREEN);
    Display_SetLevel(i*5+3,Spectrum_Level[i],GREEN);
    Display_ShowPoint(i*5+1,Spectrum_Dot[i]/10,RED);
    Display_ShowPoint(i*5+2,Spectrum_Dot[i]/10,RED);
    Display_ShowPoint(i*5+3,Spectrum_Dot[i]/10,RED);
  }
	Display_Update();
}
