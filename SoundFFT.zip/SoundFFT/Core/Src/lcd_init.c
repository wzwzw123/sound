#include "lcd_init.h"
#include "spi.h"
#define       spi_num 40
__IO bool     spi_p = 0;
__IO uint8_t  spi_buf[2][spi_num] = {0};
__IO uint8_t  spi_cnt             =  0 ;
__IO lcd_item spi_Item          = LCD_N;
__IO lcd_item nxt_Item          = LCD_N;
/******************************************************************************
      ����˵����LCD��������д�뺯��
      ������ݣ�dat  Ҫд��Ĵ�������
      ����ֵ��  ��
******************************************************************************/
void LCD_Send_Bus(void)
{
  while(spi_Item!=LCD_N);
  spi_Item = nxt_Item;
  nxt_Item = LCD_N;
  LCD_CS_Clr(spi_Item);
  HAL_SPI_Transmit_DMA(&hspi1,(uint8_t*)&spi_buf[spi_p],spi_cnt);
  spi_p = !spi_p;
  spi_cnt = 0;
}

void LCD_Writ_Bus(lcd_item Item, uint8_t dat)
{
  if(nxt_Item==LCD_N)
  {
    nxt_Item = Item;
  }
  else if(nxt_Item!=Item||spi_cnt==spi_num)
  {
    LCD_Send_Bus();
    nxt_Item = Item;
  }
  spi_buf[spi_p][spi_cnt++]=dat;
//  LCD_CS_Clr(Item);
//  HAL_SPI_Transmit_DMA(&hspi1,&dat,1);
//  while(HAL_SPI_GetState(&hspi1)!=HAL_SPI_STATE_READY);
//  LCD_CS_Set(Item);
}

//void LCD_Writ_Bus(lcd_item Item, uint8_t dat)
//{
//  uint8_t i;
//  LCD_CS_Clr(Item);
//  for(i=0;i<8;i++)
//  {
//    LCD_SCLK_Clr();
//    if(dat&0x80){LCD_MOSI_Set();}
//    else        {LCD_MOSI_Clr();}
//    LCD_SCLK_Set();
//    dat<<=1;
//  }
//  LCD_CS_Set(Item);
//}

/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_DATA8(lcd_item Item, uint8_t dat)
{
	LCD_Writ_Bus(Item, dat);
}

/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_DATA(lcd_item Item, uint16_t dat)
{
	LCD_Writ_Bus(Item, dat>>8);
	LCD_Writ_Bus(Item, dat);
}

/******************************************************************************
      ����˵����LCDд������
      ������ݣ�dat д�������
      ����ֵ��  ��
******************************************************************************/
void LCD_WR_REG(lcd_item Item, uint8_t dat)
{
  LCD_Send_Bus();
  while(spi_Item!=LCD_N);
	LCD_DC_Clr();//д����
	LCD_Writ_Bus(Item, dat);
  LCD_Send_Bus();
  while(spi_Item!=LCD_N);
	LCD_DC_Set();//д����
}

/******************************************************************************
      ����˵����������ʼ�ͽ�����ַ
      ������ݣ�x1,x2 �����е���ʼ�ͽ�����ַ
                y1,y2 �����е���ʼ�ͽ�����ַ
      ����ֵ��  ��
******************************************************************************/
const uint16_t offset[3][2][2] = {{{35,0},{0,35}}};
void LCD_Address_Set(lcd_item Item, uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2)
{
		LCD_WR_REG(Item, 0x2a);//�е�ַ����
		LCD_WR_DATA(Item, x1+offset[Item][USE_M_HORIZONTAL/2][0]);
		LCD_WR_DATA(Item, x2+offset[Item][USE_M_HORIZONTAL/2][0]);
		LCD_WR_REG(Item, 0x2b);//�е�ַ����
		LCD_WR_DATA(Item, y1+offset[Item][USE_M_HORIZONTAL/2][1]);
		LCD_WR_DATA(Item, y2+offset[Item][USE_M_HORIZONTAL/2][1]);
		LCD_WR_REG(Item, 0x2c);//������д
}

void LCD_Init(void)
{
	LCD_RES_Clr();//��λ
	HAL_Delayms(100);
	LCD_RES_Set();
	HAL_Delayms(100);
  /********** LCD_M **********/
	LCD_WR_REG(LCD_M,0x11);
//	HAL_Delayms(120); 
	LCD_WR_REG(LCD_M,0x36); 
	if(USE_M_HORIZONTAL==0)LCD_WR_DATA8(LCD_M,0x00);
	else if(USE_M_HORIZONTAL==1)LCD_WR_DATA8(LCD_M,0xC0);
	else if(USE_M_HORIZONTAL==2)LCD_WR_DATA8(LCD_M,0x70);
	else LCD_WR_DATA8(LCD_M,0xA0);

	LCD_WR_REG(LCD_M,0x3A);
	LCD_WR_DATA8(LCD_M,0x05);

	LCD_WR_REG(LCD_M,0xB2);
	LCD_WR_DATA8(LCD_M,0x0C);
	LCD_WR_DATA8(LCD_M,0x0C);
	LCD_WR_DATA8(LCD_M,0x00);
	LCD_WR_DATA8(LCD_M,0x33);
	LCD_WR_DATA8(LCD_M,0x33); 

	LCD_WR_REG(LCD_M,0xB7); 
	LCD_WR_DATA8(LCD_M,0x35);  

	LCD_WR_REG(LCD_M,0xBB);
	LCD_WR_DATA8(LCD_M,0x1A);

	LCD_WR_REG(LCD_M,0xC0);
	LCD_WR_DATA8(LCD_M,0x2C);

	LCD_WR_REG(LCD_M,0xC2);
	LCD_WR_DATA8(LCD_M,0x01);

	LCD_WR_REG(LCD_M,0xC3);
	LCD_WR_DATA8(LCD_M,0x0B);   

	LCD_WR_REG(LCD_M,0xC4);
	LCD_WR_DATA8(LCD_M,0x20);  

	LCD_WR_REG(LCD_M,0xC6); 
	LCD_WR_DATA8(LCD_M,0x0F);    

	LCD_WR_REG(LCD_M,0xD0); 
	LCD_WR_DATA8(LCD_M,0xA4);
	LCD_WR_DATA8(LCD_M,0xA1);

	LCD_WR_REG(LCD_M,0x21); 
	LCD_WR_REG(LCD_M,0xE0);
	LCD_WR_DATA8(LCD_M,0xF0);
	LCD_WR_DATA8(LCD_M,0x00);
	LCD_WR_DATA8(LCD_M,0x04);
	LCD_WR_DATA8(LCD_M,0x04);
	LCD_WR_DATA8(LCD_M,0x04);
	LCD_WR_DATA8(LCD_M,0x05);
	LCD_WR_DATA8(LCD_M,0x29);
	LCD_WR_DATA8(LCD_M,0x33);
	LCD_WR_DATA8(LCD_M,0x3E);
	LCD_WR_DATA8(LCD_M,0x38);
	LCD_WR_DATA8(LCD_M,0x12);
	LCD_WR_DATA8(LCD_M,0x12);
	LCD_WR_DATA8(LCD_M,0x28);
	LCD_WR_DATA8(LCD_M,0x30);

	LCD_WR_REG(LCD_M,0xE1);
	LCD_WR_DATA8(LCD_M,0xF0);
	LCD_WR_DATA8(LCD_M,0x07);
	LCD_WR_DATA8(LCD_M,0x0A);
	LCD_WR_DATA8(LCD_M,0x0D);
	LCD_WR_DATA8(LCD_M,0x0B);
	LCD_WR_DATA8(LCD_M,0x07);
	LCD_WR_DATA8(LCD_M,0x28);
	LCD_WR_DATA8(LCD_M,0x33);
	LCD_WR_DATA8(LCD_M,0x3E);
	LCD_WR_DATA8(LCD_M,0x36);
	LCD_WR_DATA8(LCD_M,0x14);
	LCD_WR_DATA8(LCD_M,0x14);
	LCD_WR_DATA8(LCD_M,0x29);
	LCD_WR_DATA8(LCD_M,0x32);
  
  /*********** LCD_L ***********/
	LCD_WR_REG(LCD_L,0xEF);
	LCD_WR_REG(LCD_L,0xEB);
	LCD_WR_DATA8(LCD_L,0x14);
	
  LCD_WR_REG(LCD_L,0xFE);
	LCD_WR_REG(LCD_L,0xEF);

	LCD_WR_REG(LCD_L,0xEB);
	LCD_WR_DATA8(LCD_L,0x14);

	LCD_WR_REG(LCD_L,0x84);
	LCD_WR_DATA8(LCD_L,0x40);

	LCD_WR_REG(LCD_L,0x85);
	LCD_WR_DATA8(LCD_L,0xFF);

	LCD_WR_REG(LCD_L,0x86);
	LCD_WR_DATA8(LCD_L,0xFF);

	LCD_WR_REG(LCD_L,0x87);
	LCD_WR_DATA8(LCD_L,0xFF);

	LCD_WR_REG(LCD_L,0x88);
	LCD_WR_DATA8(LCD_L,0x0A);

	LCD_WR_REG(LCD_L,0x89);
	LCD_WR_DATA8(LCD_L,0x21);

	LCD_WR_REG(LCD_L,0x8A);
	LCD_WR_DATA8(LCD_L,0x00);

	LCD_WR_REG(LCD_L,0x8B);
	LCD_WR_DATA8(LCD_L,0x80);

	LCD_WR_REG(LCD_L,0x8C);
	LCD_WR_DATA8(LCD_L,0x01);

	LCD_WR_REG(LCD_L,0x8D);
	LCD_WR_DATA8(LCD_L,0x01);

	LCD_WR_REG(LCD_L,0x8E);
	LCD_WR_DATA8(LCD_L,0xFF);

	LCD_WR_REG(LCD_L,0x8F);
	LCD_WR_DATA8(LCD_L,0xFF);


	LCD_WR_REG(LCD_L,0xB6);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0x20);

	LCD_WR_REG(LCD_L,0x36);
	if(USE_L_HORIZONTAL==0)LCD_WR_DATA8(LCD_L,0x08);
	else if(USE_L_HORIZONTAL==1)LCD_WR_DATA8(LCD_L,0xC8);
	else if(USE_L_HORIZONTAL==2)LCD_WR_DATA8(LCD_L,0x68);
	else LCD_WR_DATA8(LCD_L,0xA8);

	LCD_WR_REG(LCD_L,0x3A);
	LCD_WR_DATA8(LCD_L,0x05); 


	LCD_WR_REG(LCD_L,0x90);
	LCD_WR_DATA8(LCD_L,0x08);
	LCD_WR_DATA8(LCD_L,0x08);
	LCD_WR_DATA8(LCD_L,0x08);
	LCD_WR_DATA8(LCD_L,0x08); 

	LCD_WR_REG(LCD_L,0xBD);
	LCD_WR_DATA8(LCD_L,0x06);
	
	LCD_WR_REG(LCD_L,0xBC);
	LCD_WR_DATA8(LCD_L,0x00);

	LCD_WR_REG(LCD_L,0xFF);
	LCD_WR_DATA8(LCD_L,0x60);
	LCD_WR_DATA8(LCD_L,0x01);
	LCD_WR_DATA8(LCD_L,0x04);

	LCD_WR_REG(LCD_L,0xC3);
	LCD_WR_DATA8(LCD_L,0x13);
	LCD_WR_REG(LCD_L,0xC4);
	LCD_WR_DATA8(LCD_L,0x13);

	LCD_WR_REG(LCD_L,0xC9);
	LCD_WR_DATA8(LCD_L,0x22);

	LCD_WR_REG(LCD_L,0xBE);
	LCD_WR_DATA8(LCD_L,0x11);

	LCD_WR_REG(LCD_L,0xE1);
	LCD_WR_DATA8(LCD_L,0x10);
	LCD_WR_DATA8(LCD_L,0x0E);

	LCD_WR_REG(LCD_L,0xDF);
	LCD_WR_DATA8(LCD_L,0x21);
	LCD_WR_DATA8(LCD_L,0x0c);
	LCD_WR_DATA8(LCD_L,0x02);

	LCD_WR_REG(LCD_L,0xF0);
	LCD_WR_DATA8(LCD_L,0x45);
	LCD_WR_DATA8(LCD_L,0x09);
	LCD_WR_DATA8(LCD_L,0x08);
	LCD_WR_DATA8(LCD_L,0x08);
	LCD_WR_DATA8(LCD_L,0x26);
 	LCD_WR_DATA8(LCD_L,0x2A);

 	LCD_WR_REG(LCD_L,0xF1);
 	LCD_WR_DATA8(LCD_L,0x43);
 	LCD_WR_DATA8(LCD_L,0x70);
 	LCD_WR_DATA8(LCD_L,0x72);
 	LCD_WR_DATA8(LCD_L,0x36);
 	LCD_WR_DATA8(LCD_L,0x37);
 	LCD_WR_DATA8(LCD_L,0x6F);


 	LCD_WR_REG(LCD_L,0xF2);
 	LCD_WR_DATA8(LCD_L,0x45);
 	LCD_WR_DATA8(LCD_L,0x09);
 	LCD_WR_DATA8(LCD_L,0x08);
 	LCD_WR_DATA8(LCD_L,0x08);
 	LCD_WR_DATA8(LCD_L,0x26);
 	LCD_WR_DATA8(LCD_L,0x2A);

 	LCD_WR_REG(LCD_L,0xF3);
 	LCD_WR_DATA8(LCD_L,0x43);
 	LCD_WR_DATA8(LCD_L,0x70);
 	LCD_WR_DATA8(LCD_L,0x72);
 	LCD_WR_DATA8(LCD_L,0x36);
 	LCD_WR_DATA8(LCD_L,0x37);
 	LCD_WR_DATA8(LCD_L,0x6F);

	LCD_WR_REG(LCD_L,0xED);
	LCD_WR_DATA8(LCD_L,0x1B);
	LCD_WR_DATA8(LCD_L,0x0B);

	LCD_WR_REG(LCD_L,0xAE);
	LCD_WR_DATA8(LCD_L,0x77);
	
	LCD_WR_REG(LCD_L,0xCD);
	LCD_WR_DATA8(LCD_L,0x63);


	LCD_WR_REG(LCD_L,0x70);
	LCD_WR_DATA8(LCD_L,0x07);
	LCD_WR_DATA8(LCD_L,0x07);
	LCD_WR_DATA8(LCD_L,0x04);
	LCD_WR_DATA8(LCD_L,0x0E);
	LCD_WR_DATA8(LCD_L,0x0F);
	LCD_WR_DATA8(LCD_L,0x09);
	LCD_WR_DATA8(LCD_L,0x07);
	LCD_WR_DATA8(LCD_L,0x08);
	LCD_WR_DATA8(LCD_L,0x03);

	LCD_WR_REG(LCD_L,0xE8);
	LCD_WR_DATA8(LCD_L,0x34);

	LCD_WR_REG(LCD_L,0x62);
	LCD_WR_DATA8(LCD_L,0x18);
	LCD_WR_DATA8(LCD_L,0x0D);
	LCD_WR_DATA8(LCD_L,0x71);
	LCD_WR_DATA8(LCD_L,0xED);
	LCD_WR_DATA8(LCD_L,0x70);
	LCD_WR_DATA8(LCD_L,0x70);
	LCD_WR_DATA8(LCD_L,0x18);
	LCD_WR_DATA8(LCD_L,0x0F);
	LCD_WR_DATA8(LCD_L,0x71);
	LCD_WR_DATA8(LCD_L,0xEF);
	LCD_WR_DATA8(LCD_L,0x70);
	LCD_WR_DATA8(LCD_L,0x70);

	LCD_WR_REG(LCD_L,0x63);
	LCD_WR_DATA8(LCD_L,0x18);
	LCD_WR_DATA8(LCD_L,0x11);
	LCD_WR_DATA8(LCD_L,0x71);
	LCD_WR_DATA8(LCD_L,0xF1);
	LCD_WR_DATA8(LCD_L,0x70);
	LCD_WR_DATA8(LCD_L,0x70);
	LCD_WR_DATA8(LCD_L,0x18);
	LCD_WR_DATA8(LCD_L,0x13);
	LCD_WR_DATA8(LCD_L,0x71);
	LCD_WR_DATA8(LCD_L,0xF3);
	LCD_WR_DATA8(LCD_L,0x70);
	LCD_WR_DATA8(LCD_L,0x70);

	LCD_WR_REG(LCD_L,0x64);
	LCD_WR_DATA8(LCD_L,0x28);
	LCD_WR_DATA8(LCD_L,0x29);
	LCD_WR_DATA8(LCD_L,0xF1);
	LCD_WR_DATA8(LCD_L,0x01);
	LCD_WR_DATA8(LCD_L,0xF1);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0x07);

	LCD_WR_REG(LCD_L,0x66);
	LCD_WR_DATA8(LCD_L,0x3C);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0xCD);
	LCD_WR_DATA8(LCD_L,0x67);
	LCD_WR_DATA8(LCD_L,0x45);
	LCD_WR_DATA8(LCD_L,0x45);
	LCD_WR_DATA8(LCD_L,0x10);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0x00);

	LCD_WR_REG(LCD_L,0x67);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0x3C);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0x01);
	LCD_WR_DATA8(LCD_L,0x54);
	LCD_WR_DATA8(LCD_L,0x10);
	LCD_WR_DATA8(LCD_L,0x32);
	LCD_WR_DATA8(LCD_L,0x98);

	LCD_WR_REG(LCD_L,0x74);
	LCD_WR_DATA8(LCD_L,0x10);
	LCD_WR_DATA8(LCD_L,0x85);
	LCD_WR_DATA8(LCD_L,0x80);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0x00);
	LCD_WR_DATA8(LCD_L,0x4E);
	LCD_WR_DATA8(LCD_L,0x00);
	
  LCD_WR_REG(LCD_L,0x98);
	LCD_WR_DATA8(LCD_L,0x3e);
	LCD_WR_DATA8(LCD_L,0x07);

	LCD_WR_REG(LCD_L,0x35);
	LCD_WR_REG(LCD_L,0x21);

  /*********** LCD_R **********/
	LCD_WR_REG(LCD_R,0xEF);
	LCD_WR_REG(LCD_R,0xEB);
	LCD_WR_DATA8(LCD_R,0x14);
	
  LCD_WR_REG(LCD_R,0xFE);
	LCD_WR_REG(LCD_R,0xEF); 

	LCD_WR_REG(LCD_R,0xEB);
	LCD_WR_DATA8(LCD_R,0x14);

	LCD_WR_REG(LCD_R,0x84);
	LCD_WR_DATA8(LCD_R,0x40);

	LCD_WR_REG(LCD_R,0x85);
	LCD_WR_DATA8(LCD_R,0xFF);

	LCD_WR_REG(LCD_R,0x86);
	LCD_WR_DATA8(LCD_R,0xFF);

	LCD_WR_REG(LCD_R,0x87);
	LCD_WR_DATA8(LCD_R,0xFF);

	LCD_WR_REG(LCD_R,0x88);
	LCD_WR_DATA8(LCD_R,0x0A);

	LCD_WR_REG(LCD_R,0x89);
	LCD_WR_DATA8(LCD_R,0x21);

	LCD_WR_REG(LCD_R,0x8A);
	LCD_WR_DATA8(LCD_R,0x00);

	LCD_WR_REG(LCD_R,0x8B);
	LCD_WR_DATA8(LCD_R,0x80);

	LCD_WR_REG(LCD_R,0x8C);
	LCD_WR_DATA8(LCD_R,0x01);

	LCD_WR_REG(LCD_R,0x8D);
	LCD_WR_DATA8(LCD_R,0x01);

	LCD_WR_REG(LCD_R,0x8E);
	LCD_WR_DATA8(LCD_R,0xFF);

	LCD_WR_REG(LCD_R,0x8F);
	LCD_WR_DATA8(LCD_R,0xFF);


	LCD_WR_REG(LCD_R,0xB6);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0x20);

	LCD_WR_REG(LCD_R,0x36);
	if(USE_R_HORIZONTAL==0)LCD_WR_DATA8(LCD_R,0x08);
	else if(USE_R_HORIZONTAL==1)LCD_WR_DATA8(LCD_R,0xC8);
	else if(USE_R_HORIZONTAL==2)LCD_WR_DATA8(LCD_R,0x68);
	else LCD_WR_DATA8(LCD_R,0xA8);

	LCD_WR_REG(LCD_R,0x3A);
	LCD_WR_DATA8(LCD_R,0x05);


	LCD_WR_REG(LCD_R,0x90);
	LCD_WR_DATA8(LCD_R,0x08);
	LCD_WR_DATA8(LCD_R,0x08);
	LCD_WR_DATA8(LCD_R,0x08);
	LCD_WR_DATA8(LCD_R,0x08);

	LCD_WR_REG(LCD_R,0xBD);
	LCD_WR_DATA8(LCD_R,0x06);
	
	LCD_WR_REG(LCD_R,0xBC);
	LCD_WR_DATA8(LCD_R,0x00);

	LCD_WR_REG(LCD_R,0xFF);
	LCD_WR_DATA8(LCD_R,0x60);
	LCD_WR_DATA8(LCD_R,0x01);
	LCD_WR_DATA8(LCD_R,0x04);

	LCD_WR_REG(LCD_R,0xC3);
	LCD_WR_DATA8(LCD_R,0x13);
	LCD_WR_REG(LCD_R,0xC4);
	LCD_WR_DATA8(LCD_R,0x13);

	LCD_WR_REG(LCD_R,0xC9);
	LCD_WR_DATA8(LCD_R,0x22);

	LCD_WR_REG(LCD_R,0xBE);
	LCD_WR_DATA8(LCD_R,0x11);

	LCD_WR_REG(LCD_R,0xE1);
	LCD_WR_DATA8(LCD_R,0x10);
	LCD_WR_DATA8(LCD_R,0x0E);

	LCD_WR_REG(LCD_R,0xDF);
	LCD_WR_DATA8(LCD_R,0x21);
	LCD_WR_DATA8(LCD_R,0x0c);
	LCD_WR_DATA8(LCD_R,0x02);

	LCD_WR_REG(LCD_R,0xF0);
	LCD_WR_DATA8(LCD_R,0x45);
	LCD_WR_DATA8(LCD_R,0x09);
	LCD_WR_DATA8(LCD_R,0x08);
	LCD_WR_DATA8(LCD_R,0x08);
	LCD_WR_DATA8(LCD_R,0x26);
 	LCD_WR_DATA8(LCD_R,0x2A);

 	LCD_WR_REG(LCD_R,0xF1);
 	LCD_WR_DATA8(LCD_R,0x43);
 	LCD_WR_DATA8(LCD_R,0x70);
 	LCD_WR_DATA8(LCD_R,0x72);
 	LCD_WR_DATA8(LCD_R,0x36);
 	LCD_WR_DATA8(LCD_R,0x37);
 	LCD_WR_DATA8(LCD_R,0x6F);


 	LCD_WR_REG(LCD_R,0xF2);
 	LCD_WR_DATA8(LCD_R,0x45);
 	LCD_WR_DATA8(LCD_R,0x09);
 	LCD_WR_DATA8(LCD_R,0x08);
 	LCD_WR_DATA8(LCD_R,0x08);
 	LCD_WR_DATA8(LCD_R,0x26);
 	LCD_WR_DATA8(LCD_R,0x2A);

 	LCD_WR_REG(LCD_R,0xF3);
 	LCD_WR_DATA8(LCD_R,0x43);
 	LCD_WR_DATA8(LCD_R,0x70);
 	LCD_WR_DATA8(LCD_R,0x72);
 	LCD_WR_DATA8(LCD_R,0x36);
 	LCD_WR_DATA8(LCD_R,0x37);
 	LCD_WR_DATA8(LCD_R,0x6F);

	LCD_WR_REG(LCD_R,0xED);
	LCD_WR_DATA8(LCD_R,0x1B);
	LCD_WR_DATA8(LCD_R,0x0B);

	LCD_WR_REG(LCD_R,0xAE);
	LCD_WR_DATA8(LCD_R,0x77);
	
	LCD_WR_REG(LCD_R,0xCD);
	LCD_WR_DATA8(LCD_R,0x63);


	LCD_WR_REG(LCD_R,0x70);
	LCD_WR_DATA8(LCD_R,0x07);
	LCD_WR_DATA8(LCD_R,0x07);
	LCD_WR_DATA8(LCD_R,0x04);
	LCD_WR_DATA8(LCD_R,0x0E);
	LCD_WR_DATA8(LCD_R,0x0F);
	LCD_WR_DATA8(LCD_R,0x09);
	LCD_WR_DATA8(LCD_R,0x07);
	LCD_WR_DATA8(LCD_R,0x08);
	LCD_WR_DATA8(LCD_R,0x03);

	LCD_WR_REG(LCD_R,0xE8);
	LCD_WR_DATA8(LCD_R,0x34);

	LCD_WR_REG(LCD_R,0x62);
	LCD_WR_DATA8(LCD_R,0x18);
	LCD_WR_DATA8(LCD_R,0x0D);
	LCD_WR_DATA8(LCD_R,0x71);
	LCD_WR_DATA8(LCD_R,0xED);
	LCD_WR_DATA8(LCD_R,0x70);
	LCD_WR_DATA8(LCD_R,0x70);
	LCD_WR_DATA8(LCD_R,0x18);
	LCD_WR_DATA8(LCD_R,0x0F);
	LCD_WR_DATA8(LCD_R,0x71);
	LCD_WR_DATA8(LCD_R,0xEF);
	LCD_WR_DATA8(LCD_R,0x70);
	LCD_WR_DATA8(LCD_R,0x70);

	LCD_WR_REG(LCD_R,0x63);
	LCD_WR_DATA8(LCD_R,0x18);
	LCD_WR_DATA8(LCD_R,0x11);
	LCD_WR_DATA8(LCD_R,0x71);
	LCD_WR_DATA8(LCD_R,0xF1);
	LCD_WR_DATA8(LCD_R,0x70);
	LCD_WR_DATA8(LCD_R,0x70);
	LCD_WR_DATA8(LCD_R,0x18);
	LCD_WR_DATA8(LCD_R,0x13);
	LCD_WR_DATA8(LCD_R,0x71);
	LCD_WR_DATA8(LCD_R,0xF3);
	LCD_WR_DATA8(LCD_R,0x70);
	LCD_WR_DATA8(LCD_R,0x70);

	LCD_WR_REG(LCD_R,0x64);
	LCD_WR_DATA8(LCD_R,0x28);
	LCD_WR_DATA8(LCD_R,0x29);
	LCD_WR_DATA8(LCD_R,0xF1);
	LCD_WR_DATA8(LCD_R,0x01);
	LCD_WR_DATA8(LCD_R,0xF1);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0x07);

	LCD_WR_REG(LCD_R,0x66);
	LCD_WR_DATA8(LCD_R,0x3C);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0xCD);
	LCD_WR_DATA8(LCD_R,0x67);
	LCD_WR_DATA8(LCD_R,0x45);
	LCD_WR_DATA8(LCD_R,0x45);
	LCD_WR_DATA8(LCD_R,0x10);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0x00);

	LCD_WR_REG(LCD_R,0x67);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0x3C);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0x01);
	LCD_WR_DATA8(LCD_R,0x54);
	LCD_WR_DATA8(LCD_R,0x10);
	LCD_WR_DATA8(LCD_R,0x32);
	LCD_WR_DATA8(LCD_R,0x98);

	LCD_WR_REG(LCD_R,0x74);
	LCD_WR_DATA8(LCD_R,0x10);
	LCD_WR_DATA8(LCD_R,0x85);
	LCD_WR_DATA8(LCD_R,0x80);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0x00);
	LCD_WR_DATA8(LCD_R,0x4E);
	LCD_WR_DATA8(LCD_R,0x00);
	
  LCD_WR_REG(LCD_R,0x98);
	LCD_WR_DATA8(LCD_R,0x3e);
	LCD_WR_DATA8(LCD_R,0x07);

	LCD_WR_REG(LCD_R,0x35);
	LCD_WR_REG(LCD_R,0x21);

  /****************************/
	LCD_WR_REG(LCD_L,0x11);
	LCD_WR_REG(LCD_R,0x11);
  LCD_WR_REG(LCD_M,0x11);
  HAL_Delayms(120);
	LCD_WR_REG(LCD_L,0x29);
	LCD_WR_REG(LCD_R,0x29);
	LCD_WR_REG(LCD_M,0x29); 
  
  
  
	LCD_BLK_Set(LCD_L);//�򿪱���
	LCD_BLK_Set(LCD_R);//�򿪱���
	LCD_BLK_Set(LCD_M);//�򿪱���
}
