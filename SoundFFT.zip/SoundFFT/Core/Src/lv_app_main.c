#include "lv_app_main.h"
#include "Spectrum.h"

///////////////////// VARIABLES ////////////////////
lv_obj_t * ui_Screen1;
lv_obj_t * ui_PanelL1;
lv_obj_t * ui_LabelUsb;
lv_obj_t * ui_ImageL1;
lv_obj_t * ui_PanelR1;
lv_obj_t * ui_LabelTempHumi;
lv_obj_t * ui_Date;
lv_obj_t * ui_LabelTittleV;
lv_obj_t * ui_CPUF;
lv_obj_t * ui_GPUF;
lv_obj_t * ui_CPUR;
lv_obj_t * ui_GPUR;
lv_obj_t * ui_CPUT;
lv_obj_t * ui_GPUT;
lv_obj_t * ui_ImageR1;
lv_obj_t * ui_PanelM1;
lv_obj_t * ui_FFT;
lv_obj_t * ui_Screen2;
lv_obj_t * ui_PanelL2;
lv_obj_t * ui_ImageL2;
lv_obj_t * ui_PanelR2;
lv_obj_t * ui_ImageR2;
lv_obj_t * ui_PanelM2;
lv_obj_t * ui_ImageM2;

lv_coord_t * ser_array;

///////////////////// TEST LVGL SETTINGS ////////////////////
#if LV_COLOR_DEPTH != 16
    #error "LV_COLOR_DEPTH should be 16bit to match SquareLine Studio's settings"
#endif
#if LV_COLOR_16_SWAP !=0
    #error "LV_COLOR_16_SWAP should be 0 to match SquareLine Studio's settings"
#endif

///////////////////// ANIMATIONS ////////////////////

///////////////////// FUNCTIONS ////////////////////

///////////////////// SCREENS ////////////////////
void ui_Screen1_screen_init(void)
{
    ui_Screen1 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen1, LV_OBJ_FLAG_SCROLLABLE);      /// Flags
    lv_obj_set_style_bg_color(ui_Screen1, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen1, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_PanelL1 = lv_obj_create(ui_Screen1);
    lv_obj_set_width(ui_PanelL1, 240);
    lv_obj_set_height(ui_PanelL1, 240);
    lv_obj_clear_flag(ui_PanelL1, LV_OBJ_FLAG_SCROLLABLE);      /// Flags
    lv_obj_set_style_radius(ui_PanelL1, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui_PanelL1, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_PanelL1, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_LabelUsb = lv_label_create(ui_PanelL1);
    lv_obj_set_width(ui_LabelUsb, 156);
    lv_obj_set_height(ui_LabelUsb, 176);
    lv_obj_set_align(ui_LabelUsb, LV_ALIGN_CENTER);
    lv_label_set_text(ui_LabelUsb,
                      "Normal USB Intensity\n1 : 0A           2: 0A\n3: 0A           4: 0A\n5: 0A           6: 0A\n7: 0A           8: 0A\n\nSuper Charge\nUSB1\nU: 5V            I : 0A\nUSB2\nU: 5V            I : 0A");
    lv_obj_set_style_text_color(ui_LabelUsb, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_LabelUsb, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_LabelUsb, &lv_font_montserrat_14, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_ImageL1 = lv_img_create(ui_PanelL1);
    lv_obj_set_width(ui_ImageL1, LV_SIZE_CONTENT);   /// 240
    lv_obj_set_height(ui_ImageL1, LV_SIZE_CONTENT);    /// 240
    lv_obj_set_align(ui_ImageL1, LV_ALIGN_CENTER);
    lv_obj_add_flag(ui_ImageL1, LV_OBJ_FLAG_HIDDEN);     /// Flags

    ui_PanelR1 = lv_obj_create(ui_Screen1);
    lv_obj_set_width(ui_PanelR1, 240);
    lv_obj_set_height(ui_PanelR1, 240);
    lv_obj_set_x(ui_PanelR1, 240);
    lv_obj_set_y(ui_PanelR1, 0);
    lv_obj_clear_flag(ui_PanelR1, LV_OBJ_FLAG_SCROLLABLE);      /// Flags
    lv_obj_set_style_radius(ui_PanelR1, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui_PanelR1, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_PanelR1, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_LabelTempHumi = lv_label_create(ui_PanelR1);
    lv_obj_set_width(ui_LabelTempHumi, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_LabelTempHumi, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_LabelTempHumi, 0);
    lv_obj_set_y(ui_LabelTempHumi, -70);
    lv_obj_set_align(ui_LabelTempHumi, LV_ALIGN_CENTER);
    lv_label_set_text(ui_LabelTempHumi, "            Environment\nTemp: 25.6C     Humi :43.4%");
    lv_obj_set_style_text_color(ui_LabelTempHumi, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_LabelTempHumi, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_Date = lv_label_create(ui_PanelR1);
    lv_obj_set_width(ui_Date, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_Date, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_Date, 0);
    lv_obj_set_y(ui_Date, -30);
    lv_obj_set_align(ui_Date, LV_ALIGN_CENTER);
    lv_label_set_text(ui_Date, "0000/00/00    00:00");
    lv_obj_set_style_text_color(ui_Date, lv_color_hex(0xFFFFFF), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui_Date, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui_Date, &lv_font_montserrat_24, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_LabelTittleV = lv_label_create(ui_PanelR1);
    lv_obj_set_width(ui_LabelTittleV, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_LabelTittleV, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_LabelTittleV, 0);
    lv_obj_set_y(ui_LabelTittleV, 30);
    lv_obj_set_align(ui_LabelTittleV, LV_ALIGN_CENTER);
    lv_label_set_text(ui_LabelTittleV, "PC         Freq  Rate Temp\nDevice  MHz     %       C\nCPU\nGPU");

    ui_CPUF = lv_label_create(ui_PanelR1);
    lv_obj_set_width(ui_CPUF, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_CPUF, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_CPUF, -15);
    lv_obj_set_y(ui_CPUF, 38);
    lv_obj_set_align(ui_CPUF, LV_ALIGN_CENTER);
    lv_label_set_text(ui_CPUF, "0");

    ui_GPUF = lv_label_create(ui_PanelR1);
    lv_obj_set_width(ui_GPUF, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_GPUF, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_GPUF, -15);
    lv_obj_set_y(ui_GPUF, 54);
    lv_obj_set_align(ui_GPUF, LV_ALIGN_CENTER);
    lv_label_set_text(ui_GPUF, "0");

    ui_CPUR = lv_label_create(ui_PanelR1);
    lv_obj_set_width(ui_CPUR, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_CPUR, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_CPUR, 26);
    lv_obj_set_y(ui_CPUR, 38);
    lv_obj_set_align(ui_CPUR, LV_ALIGN_CENTER);
    lv_label_set_text(ui_CPUR, "0");

    ui_GPUR = lv_label_create(ui_PanelR1);
    lv_obj_set_width(ui_GPUR, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_GPUR, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_GPUR, 26);
    lv_obj_set_y(ui_GPUR, 54);
    lv_obj_set_align(ui_GPUR, LV_ALIGN_CENTER);
    lv_label_set_text(ui_GPUR, "0");

    ui_CPUT = lv_label_create(ui_PanelR1);
    lv_obj_set_width(ui_CPUT, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_CPUT, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_CPUT, 65);
    lv_obj_set_y(ui_CPUT, 38);
    lv_obj_set_align(ui_CPUT, LV_ALIGN_CENTER);
    lv_label_set_text(ui_CPUT, "0");

    ui_GPUT = lv_label_create(ui_PanelR1);
    lv_obj_set_width(ui_GPUT, LV_SIZE_CONTENT);   /// 1
    lv_obj_set_height(ui_GPUT, LV_SIZE_CONTENT);    /// 1
    lv_obj_set_x(ui_GPUT, 65);
    lv_obj_set_y(ui_GPUT, 54);
    lv_obj_set_align(ui_GPUT, LV_ALIGN_CENTER);
    lv_label_set_text(ui_GPUT, "0");

    ui_ImageR1 = lv_img_create(ui_PanelR1);
    lv_obj_set_width(ui_ImageR1, LV_SIZE_CONTENT);   /// 240
    lv_obj_set_height(ui_ImageR1, LV_SIZE_CONTENT);    /// 240
    lv_obj_set_align(ui_ImageR1, LV_ALIGN_CENTER);
    lv_obj_add_flag(ui_ImageR1, LV_OBJ_FLAG_HIDDEN);     /// Flags

    ui_PanelM1 = lv_obj_create(ui_Screen1);
    lv_obj_set_width(ui_PanelM1, 320);
    lv_obj_set_height(ui_PanelM1, 170);
    lv_obj_set_x(ui_PanelM1, 0);
    lv_obj_set_y(ui_PanelM1, 240);
    lv_obj_clear_flag(ui_PanelM1, LV_OBJ_FLAG_SCROLLABLE);      /// Flags
    lv_obj_set_style_radius(ui_PanelM1, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui_PanelM1, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_PanelM1, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_FFT = lv_chart_create(ui_PanelM1);
    lv_obj_set_size(ui_FFT, 320, 170);
    lv_obj_center(ui_FFT);
    lv_chart_set_type(ui_FFT, LV_CHART_TYPE_BAR);
    lv_chart_set_range(ui_FFT, LV_CHART_AXIS_PRIMARY_Y, 0, 170);
    lv_chart_set_point_count(ui_FFT, 14);
    lv_obj_set_style_radius(ui_FFT, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui_FFT, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_FFT, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_chart_set_div_line_count(ui_FFT, 0, 0);
    lv_chart_series_t * ser = lv_chart_add_series(ui_FFT, lv_palette_lighten(LV_PALETTE_GREEN, 2), LV_CHART_AXIS_PRIMARY_Y);
    ser_array = lv_chart_get_y_array(ui_FFT, ser);

//    ser_array[0] = 92;
//    ser_array[1] = 71;
//    ser_array[2] = 61;
//    ser_array[3] = 15;
//    ser_array[4] = 21;
//    ser_array[5] = 35;
//    ser_array[6] = 35;
//    ser_array[7] = 58;
//    ser_array[8] = 31;
//    ser_array[9] = 53;
//    ser_array[10] = 33;
//    ser_array[11] = 73;
//    ser_array[12] = 73;
//    ser_array[13] = 73;

//    lv_chart_refresh(ui_FFT); /*Required after direct set*/
}

void ui_Screen2_screen_init(void)
{
    ui_Screen2 = lv_obj_create(NULL);
    lv_obj_clear_flag(ui_Screen2, LV_OBJ_FLAG_SCROLLABLE);      /// Flags
    lv_obj_set_style_bg_color(ui_Screen2, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_Screen2, 255, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_PanelL2 = lv_obj_create(ui_Screen2);
    lv_obj_set_width(ui_PanelL2, 240);
    lv_obj_set_height(ui_PanelL2, 240);
    lv_obj_clear_flag(ui_PanelL2, LV_OBJ_FLAG_SCROLLABLE);      /// Flags
    lv_obj_set_style_radius(ui_PanelL2, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui_PanelL2, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_PanelL2, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_ImageL2 = lv_img_create(ui_PanelL2);
    lv_obj_set_width(ui_ImageL2, LV_SIZE_CONTENT);   /// 240
    lv_obj_set_height(ui_ImageL2, LV_SIZE_CONTENT);    /// 240
    lv_obj_set_align(ui_ImageL2, LV_ALIGN_CENTER);

    ui_PanelR2 = lv_obj_create(ui_Screen2);
    lv_obj_set_width(ui_PanelR2, 240);
    lv_obj_set_height(ui_PanelR2, 240);
    lv_obj_set_x(ui_PanelR2, 240);
    lv_obj_set_y(ui_PanelR2, 0);
    lv_obj_clear_flag(ui_PanelR2, LV_OBJ_FLAG_SCROLLABLE);      /// Flags
    lv_obj_set_style_radius(ui_PanelR2, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui_PanelR2, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_PanelR2, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_ImageR2 = lv_img_create(ui_PanelR2);
    lv_obj_set_width(ui_ImageR2, LV_SIZE_CONTENT);   /// 240
    lv_obj_set_height(ui_ImageR2, LV_SIZE_CONTENT);    /// 240
    lv_obj_set_align(ui_ImageR2, LV_ALIGN_CENTER);

    ui_PanelM2 = lv_obj_create(ui_Screen2);
    lv_obj_set_width(ui_PanelM2, 320);
    lv_obj_set_height(ui_PanelM2, 170);
    lv_obj_set_x(ui_PanelM2, 0);
    lv_obj_set_y(ui_PanelM2, 240);
    lv_obj_clear_flag(ui_PanelM2, LV_OBJ_FLAG_SCROLLABLE);      /// Flags
    lv_obj_set_style_radius(ui_PanelM2, 0, LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui_PanelM2, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui_PanelM2, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

    ui_ImageM2 = lv_img_create(ui_PanelM2);
    lv_obj_set_width(ui_ImageM2, LV_SIZE_CONTENT);   /// 320
    lv_obj_set_height(ui_ImageM2, LV_SIZE_CONTENT);    /// 170
    lv_obj_set_align(ui_ImageM2, LV_ALIGN_CENTER);

}
void HAL_Delay(uint32_t ms);
void lv_app_main_init(lv_obj_t * screen, const void * src_l0, const void * src_r0, const void * src_m0,
                                         const void * src_l1, const void * src_r1,
                                         const void * src_l2, const void * src_r2, const void * src_m2)
{
    lv_disp_t * dispp = lv_disp_get_default();
    lv_theme_t * theme = lv_theme_default_init(dispp, lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_RED),
                                               true, LV_FONT_DEFAULT);
    lv_disp_set_theme(dispp, theme);
    ui_Screen1_screen_init();
    ui_Screen2_screen_init();

    lv_img_set_src(ui_ImageL2, src_l0);
    lv_img_set_src(ui_ImageR2, src_r0);
    lv_img_set_src(ui_ImageM2, src_m0);

    lv_disp_load_scr(ui_Screen2);
    lv_task_handler();
    lv_disp_load_scr(ui_Screen2);
    lv_task_handler();
    HAL_Delay(2000);

    lv_img_set_src(ui_ImageL1, src_l1);
    lv_img_set_src(ui_ImageR1, src_r1);
    lv_img_set_src(ui_ImageL2, src_l2);
    lv_img_set_src(ui_ImageR2, src_r2);
    lv_img_set_src(ui_ImageM2, src_m2);
    lv_disp_load_scr(ui_Screen1);
    lv_task_handler();

//    lv_disp_load_scr(ui_Screen2);
//    lv_task_handler();

}

void lv_task_scr1(void)
{
    static bool      mode     = 1;
    static uint16_t tim_count = 0;
    static uint8_t  img_count = 0;
    char filename[] = "A:bin/L1/00.bin";
    Spectrum_GetValue();
    Spectrum_Show();
    if(++tim_count>=500)
    {
        tim_count=0;
        mode=!mode;
        if(mode)
        {
            lv_obj_add_flag(ui_ImageL1, LV_OBJ_FLAG_HIDDEN);     /// Flags
            lv_obj_add_flag(ui_ImageR1, LV_OBJ_FLAG_HIDDEN);     /// Flags
        }
        else
        {
            lv_obj_clear_flag(ui_ImageL1, LV_OBJ_FLAG_HIDDEN);     /// Flags
            lv_obj_clear_flag(ui_ImageR1, LV_OBJ_FLAG_HIDDEN);     /// Flags
        }

    }
    if(mode)
    {
    }
    else
    {
        if(++img_count>=23)
        {
            img_count = 0;
        }
        filename[9]='0'+img_count/10%10;
        filename[10]='0'+img_count%10;
        lv_img_set_src(ui_ImageL1, filename);
        lv_img_set_src(ui_ImageR1, filename);
    }
}
void lv_task_scr2(void)
{
    static uint8_t  img_countl = 0;
    static uint8_t  img_countr = 0;
    char filenamel[] = "A:bin/L2/00.bin";
    char filenamer[] = "A:bin/R2/00.bin";
    if(++img_countl>=33)
    {
        img_countl = 0;
    }
    if(++img_countr>=9)
    {
        img_countr = 0;
    }
    filenamel[9]='0'+img_countl/10%10;
    filenamel[10]='0'+img_countl%10;
    filenamer[9]='0'+img_countr/10%10;
    filenamer[10]='0'+img_countr%10;
    lv_img_set_src(ui_ImageL2, filenamel);
    lv_img_set_src(ui_ImageR2, filenamer);

}

void lv_task_app(void)
{
    static uint16_t tim_count = 0;
    static bool mode = 1;
    if(mode)
    {
        lv_task_scr1();
    }
    else
    {
        lv_task_scr2();
    }
//    if(++tim_count>=1000)
//    {
//        tim_count = 0;
//        mode = !mode;
//        if(mode)
//        {
//            lv_disp_load_scr(ui_Screen1);
//        }
//        else
//        {
//            lv_disp_load_scr(ui_Screen2);
//        }
//    }
}
