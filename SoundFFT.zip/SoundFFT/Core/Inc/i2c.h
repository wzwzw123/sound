/*
 * i2c.h:
 * Copyright (c) 2014-2017 Rtrobot. <admin@rtrobot.org>
 *  <http://rtrobot.org>
 ***********************************************************************
 * use keil5 for arm.
 */
#ifndef __I2C_H_
#define __I2C_H_

#include "main.h"

//I2C
#define I2C_SCL_Clr()   PBout(6)=0
#define I2C_SCL_Set()   PBout(6)=1

#define I2C_SDA_Clr()   PBout(7)=0
#define I2C_SDA_Set()   PBout(7)=1
//IO��������
#define I2C_SDA_IN()   {I2C_SDA_GPIO_Port->MODER&=~(3<<(7*2));I2C_SDA_GPIO_Port->MODER|=0<<(7*2);}
#define I2C_SDA_OUT()  {I2C_SDA_GPIO_Port->MODER&=~(3<<(7*2));I2C_SDA_GPIO_Port->MODER|=1<<(7*2);}
//IO��������	 
#define I2C_SDA        PBin(7)

void I2C_Config(void);
void SDA_SetGpioMode(bool mode);
static void IIC_delay(uint16_t n);
void IIC_Start(void);
void IIC_Stop(void);
void IIC_SendByte(uint8_t data);
uint8_t IIC_RecvByte(void);
int8_t IIC_RecvACK(void);
void IIC_SendACK(uint8_t ack);
void IIC_WriteReg(uint8_t i2c_addr, uint8_t reg_addr, uint8_t reg_data);
void IIC_ReadData(uint8_t i2c_addr, uint8_t reg_addr, uint8_t * pdata);
int32_t IIC_ReadDataBlock(uint8_t i2c_addr, uint8_t reg_data, uint8_t *pdata, uint32_t count);

#endif /* __I2C_H */
