#ifndef LV_APP_MAIN_H
#define LV_APP_MAIN_H
#include "lvgl/lvgl.h"

extern lv_obj_t * ui_Screen1;
extern lv_obj_t * ui_PanelL1;
extern lv_obj_t * ui_LabelUsb;
extern lv_obj_t * ui_PanelR1;
extern lv_obj_t * ui_LabelTempHumi;
extern lv_obj_t * ui_Date;
extern lv_obj_t * ui_CPUF;
extern lv_obj_t * ui_GPUF;
extern lv_obj_t * ui_CPUR;
extern lv_obj_t * ui_GPUR;
extern lv_obj_t * ui_CPUT;
extern lv_obj_t * ui_GPUT;
extern lv_obj_t * ui_FFT;
extern lv_obj_t * ui_Screen2;
extern lv_obj_t * ui_Screen3;
extern lv_coord_t * ser_array;

void lv_app_main_init(lv_obj_t * screen, const void * src_l0, const void * src_r0, const void * src_m0,
                                         const void * src_l1, const void * src_r1,
                                         const void * src_l2, const void * src_r2, const void * src_m2);
void lv_task_app(void);
void data_set(void);
#endif // LV_APP_MAIN_H
