/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdbool.h>
#include "delay.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LCD_A_RES_Pin GPIO_PIN_4
#define LCD_A_RES_GPIO_Port GPIOC
#define LCD_A_DC_Pin GPIO_PIN_5
#define LCD_A_DC_GPIO_Port GPIOC
#define LCD_M_CS_Pin GPIO_PIN_0
#define LCD_M_CS_GPIO_Port GPIOB
#define LCD_R_CS_Pin GPIO_PIN_1
#define LCD_R_CS_GPIO_Port GPIOB
#define LCD_L_CS_Pin GPIO_PIN_2
#define LCD_L_CS_GPIO_Port GPIOB
#define LCD_M_BLK_Pin GPIO_PIN_11
#define LCD_M_BLK_GPIO_Port GPIOF
#define SDIO_TEST_Pin GPIO_PIN_8
#define SDIO_TEST_GPIO_Port GPIOA
#define I2C_SCL_Pin GPIO_PIN_6
#define I2C_SCL_GPIO_Port GPIOB
#define I2C_SDA_Pin GPIO_PIN_7
#define I2C_SDA_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */
/**  Bits definition for GPIO register  ***************************************/
/*** definition for GPIO option ***********************************************/
#define BITBAND(addr, bitnum)                ((addr & 0xF0000000)+0x2000000+((addr &0xFFFFF)<<5)+(bitnum<<2))
#define MEM_ADDR(addr)                      *((volatile unsigned long  *)(addr))
#define BIT_ADDR(addr, bitnum)                   MEM_ADDR(BITBAND(addr, bitnum))
/*** definition for GPIO address **********************************************/
/**** Bits for GPIO ODR register **********************************************/
#define GPIOA_ODR_Addr  (GPIOA_BASE+20)  //0x40020014
#define GPIOB_ODR_Addr  (GPIOB_BASE+20)  //0x40020414
#define GPIOC_ODR_Addr  (GPIOC_BASE+20)  //0x40020814
#define GPIOD_ODR_Addr  (GPIOD_BASE+20)  //0x40020C14
#define GPIOE_ODR_Addr  (GPIOE_BASE+20)  //0x40021014
#define GPIOF_ODR_Addr  (GPIOF_BASE+20)  //0x40021414
#define GPIOG_ODR_Addr  (GPIOG_BASE+20)  //0x40021814
#define GPIOH_ODR_Addr  (GPIOH_BASE+20)  //0x40021C14
#define GPIOI_ODR_Addr  (GPIOI_BASE+20)  //0x40022014
/**** Bits for GPIO IDR register **********************************************/
#define GPIOA_IDR_Addr  (GPIOA_BASE+16)  //0x40020010
#define GPIOB_IDR_Addr  (GPIOB_BASE+16)  //0x40020410
#define GPIOC_IDR_Addr  (GPIOC_BASE+16)  //0x40020810
#define GPIOD_IDR_Addr  (GPIOD_BASE+16)  //0x40020C10
#define GPIOE_IDR_Addr  (GPIOE_BASE+16)  //0x40021010
#define GPIOF_IDR_Addr  (GPIOF_BASE+16)  //0x40021410
#define GPIOG_IDR_Addr  (GPIOG_BASE+16)  //0x40021810
#define GPIOH_IDR_Addr  (GPIOH_BASE+16)  //0x40021C10
#define GPIOI_IDR_Addr  (GPIOI_BASE+16)  //0x40022010
/*** GPIO bits option *********************************************************/
#define PAout(n)    BIT_ADDR(GPIOA_ODR_Addr,n) //���
#define PAin(n)     BIT_ADDR(GPIOA_IDR_Addr,n) //����

#define PBout(n)    BIT_ADDR(GPIOB_ODR_Addr,n) //���
#define PBin(n)     BIT_ADDR(GPIOB_IDR_Addr,n) //����

#define PCout(n)    BIT_ADDR(GPIOC_ODR_Addr,n) //���
#define PCin(n)     BIT_ADDR(GPIOC_IDR_Addr,n) //����

#define PDout(n)    BIT_ADDR(GPIOD_ODR_Addr,n) //���
#define PDin(n)     BIT_ADDR(GPIOD_IDR_Addr,n) //����

#define PEout(n)    BIT_ADDR(GPIOE_ODR_Addr,n) //���
#define PEin(n)     BIT_ADDR(GPIOE_IDR_Addr,n) //����

#define PFout(n)    BIT_ADDR(GPIOF_ODR_Addr,n) //���
#define PFin(n)     BIT_ADDR(GPIOF_IDR_Addr,n) //����

#define PGout(n)    BIT_ADDR(GPIOG_ODR_Addr,n) //���
#define PGin(n)     BIT_ADDR(GPIOG_IDR_Addr,n) //����

#define PHout(n)    BIT_ADDR(GPIOH_ODR_Addr,n) //���
#define PHin(n)     BIT_ADDR(GPIOH_IDR_Addr,n) //����

#define PIout(n)    BIT_ADDR(GPIOI_ODR_Addr,n) //���
#define PIin(n)     BIT_ADDR(GPIOI_IDR_Addr,n) //����
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
