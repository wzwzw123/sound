#ifndef __LCD_INIT_H
#define __LCD_INIT_H
#include "main.h"

#define USE_M_HORIZONTAL 3  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����
#define USE_L_HORIZONTAL 1  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����
#define USE_R_HORIZONTAL 1  //���ú�������������ʾ 0��1Ϊ���� 2��3Ϊ����

#if USE_M_HORIZONTAL==0||USE_M_HORIZONTAL==1
#define LCD_M_W 170	
#define LCD_M_H 320
#else
#define LCD_M_W 320
#define LCD_M_H 170
#endif

#define LCD_L_W 240
#define LCD_L_H 240

#define LCD_R_W 240
#define LCD_R_H 240

typedef enum{
  LCD_M,
  LCD_L,
  LCD_R,
  LCD_N,
}lcd_item;

extern __IO lcd_item spi_Item;

/******************************************** LCD�˿ڶ��� ********************************************/
static GPIO_TypeDef* const LCD_CS_Port[3]=  {LCD_M_CS_GPIO_Port,  LCD_L_CS_GPIO_Port,  LCD_R_CS_GPIO_Port };
static const uint16_t      LCD_CS_Pin[3]=   {LCD_M_CS_Pin,        LCD_L_CS_Pin,        LCD_R_CS_Pin       };

static GPIO_TypeDef* const LCD_BLK_Port[3]= {LCD_M_BLK_GPIO_Port, LCD_M_BLK_GPIO_Port, LCD_M_BLK_GPIO_Port};
static const uint16_t      LCD_BLK_Pin[3]=  {LCD_M_BLK_Pin,       LCD_M_BLK_Pin,       LCD_M_BLK_Pin      };

#define LCD_SCLK_Clr() HAL_GPIO_WritePin(LCD_A_SCL_GPIO_Port,LCD_A_SCL_Pin,GPIO_PIN_RESET)//SCL=SCLK
#define LCD_SCLK_Set() HAL_GPIO_WritePin(LCD_A_SCL_GPIO_Port,LCD_A_SCL_Pin,GPIO_PIN_SET)

#define LCD_MOSI_Clr() HAL_GPIO_WritePin(LCD_A_SDA_GPIO_Port,LCD_A_SDA_Pin,GPIO_PIN_RESET)//SDA=MOSI
#define LCD_MOSI_Set() HAL_GPIO_WritePin(LCD_A_SDA_GPIO_Port,LCD_A_SDA_Pin,GPIO_PIN_SET)

#define LCD_RES_Clr()  HAL_GPIO_WritePin(LCD_A_RES_GPIO_Port,LCD_A_RES_Pin,GPIO_PIN_RESET)//RES
#define LCD_RES_Set()  HAL_GPIO_WritePin(LCD_A_RES_GPIO_Port,LCD_A_RES_Pin,GPIO_PIN_SET)

#define LCD_DC_Clr()   HAL_GPIO_WritePin(LCD_A_DC_GPIO_Port,LCD_A_DC_Pin,GPIO_PIN_RESET)//DC
#define LCD_DC_Set()   HAL_GPIO_WritePin(LCD_A_DC_GPIO_Port,LCD_A_DC_Pin,GPIO_PIN_SET)

#define LCD_CS_Clr(n)  HAL_GPIO_WritePin(LCD_CS_Port[n],LCD_CS_Pin[n],GPIO_PIN_RESET)//CS
#define LCD_CS_Set(n)  HAL_GPIO_WritePin(LCD_CS_Port[n],LCD_CS_Pin[n],GPIO_PIN_SET)

#define LCD_BLK_Clr(n) HAL_GPIO_WritePin(LCD_BLK_Port[n],LCD_BLK_Pin[n],GPIO_PIN_RESET)//BLK
#define LCD_BLK_Set(n) HAL_GPIO_WritePin(LCD_BLK_Port[n],LCD_BLK_Pin[n],GPIO_PIN_SET)
/*****************************************************************************************************/

void LCD_Writ_Bus(lcd_item Item, uint8_t dat);//ģ��SPIʱ��
void LCD_WR_DATA8(lcd_item Item, uint8_t dat);//д��һ���ֽ�
void LCD_WR_DATA(lcd_item Item, uint16_t dat);//д�������ֽ�
void LCD_WR_REG(lcd_item Item, uint8_t dat);//д��һ��ָ��
void LCD_Address_Set(lcd_item Item, uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2);//�������꺯��
void LCD_Init(void);//LCD��ʼ��
#endif
