#ifndef __SAMPLE_H
#define __SAMPLE_H
#include "main.h"

#define sample_num 1024
extern volatile HAL_StatusTypeDef sample_status;
extern uint16_t adc_buf[sample_num];
extern uint16_t *Sample_Value;

void Sample_Init(void);
void Sample_GetValue(void);

#endif
