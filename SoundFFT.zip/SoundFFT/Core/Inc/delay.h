#include "stdint.h"

#ifndef __DELAY_H
#define __DELAY_H

void HAL_DelayInit(void);
void HAL_Delayus(uint32_t us);
void HAL_Delayms(uint32_t ms);

#endif
