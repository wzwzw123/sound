#ifndef __DISPLAY_H
#define __DISPLAY_H
#include "main.h"
#include "lcd.h"
#include "lcd_init.h"

//extern uint8_t Display_Buf[LCD_M_W][LCD_M_H][2];

void Display_Init(void);
void Display_ClearBuf(void);
void Display_ClearAreaBuf(uint16_t StartX,uint16_t EndX,uint16_t StartY,uint16_t EndY);
void Display_Update(void);
void Display_SetLevel(uint16_t X,uint16_t Level,uint16_t Color);
void Display_Clear(void);
void Display_ShowChar(uint16_t X,uint16_t Y,char Char,uint8_t SizeColor);
void Display_ShowString(uint16_t X,uint16_t Y,char *String,uint8_t SizeColor);
void Display_ShowNumber(uint16_t X,uint16_t Y,uint16_t Number,uint8_t Length,uint8_t SizeColor);
void Display_ShowPoint(uint16_t X,uint16_t Y,uint16_t Color);

#endif
